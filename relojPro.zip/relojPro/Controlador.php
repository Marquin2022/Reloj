<?php
	// Controlador.php
	class Controlador {
		public function exhibir($modelo, $vista){
			$vista->dibujarReloj($modelo);
		}
	}
?>